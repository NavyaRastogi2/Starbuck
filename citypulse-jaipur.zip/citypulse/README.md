# CityPulse Jaipur (Python frontend)

A Streamlit remake of the CityPulse City Dashboard idea for Jaipur.
Modes: Pulse, Weather, Route, Ground reports. Tabs: Live map, AI Navi, Civic contributors.
All data is simulated (a monsoon evening, 5 to 8 PM) in `data.py`.

## Run
    python -m venv venv
    # Windows:  venv\Scripts\activate      Mac/Linux:  source venv/bin/activate
    pip install -r requirements.txt
    streamlit run app.py

Opens at http://localhost:8501
